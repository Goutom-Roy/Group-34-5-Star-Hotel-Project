/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication9;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

/**
 * FXML Controller class
 *
 * @author csari
 */
public class HotelReceptionstController implements Initializable {

    @FXML
    private Button GuestComplaintfxid;
    @FXML
    private Button HotelBookingfxid;
    @FXML
    private Button ProvidingInformationfxid;
    @FXML
    private Button HotelFacilitiefxid;
    @FXML
    private Button CheckInfxid;
    @FXML
    private Button CheckOutfxid;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void OnclickGuestComplaintButton(ActionEvent event) throws IOException {

    }

    @FXML
    private void OnclickHotelBookingButton(ActionEvent event) {
    }

    @FXML
    private void OnclickProvidingInformationButton(ActionEvent event) {
    }

    @FXML
    private void OnclickHotelFacilitieButton(ActionEvent event) {
    }

    @FXML
    private void OnclickCheckIbutton(ActionEvent event) {
    }

    @FXML
    private void OnclickCheckOutButton(ActionEvent event) throws IOException {

    }
    
}
