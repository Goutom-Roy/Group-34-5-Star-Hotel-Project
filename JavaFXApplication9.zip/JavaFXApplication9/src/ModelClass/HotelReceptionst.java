/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModelClass;

/**
 *
 * @author csari
 */
public class HotelReceptionst {
    
    
   
    private String name;
    private HotelBooking currentBooking;
    private String currentQuery;
    private CheckInRecord currentCheckIn;
    private CheckOutRecord currentCheckOut;

    public HotelReceptionst(String name) {
        this.name = name;
    }

    // Getters and setters for name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and setter for current booking
    public HotelBooking getCurrentBooking() {
        return currentBooking;
    }

    public void setCurrentBooking(HotelBooking currentBooking) {
        this.currentBooking = currentBooking;
    }

    // Getter and setter for current query
    public String getCurrentQuery() {
        return currentQuery;
    }

    public void setCurrentQuery(String currentQuery) {
        this.currentQuery = currentQuery;
    }

    // Getter and setter for current check-in record
    public CheckInRecord getCurrentCheckIn() {
        return currentCheckIn;
    }

    public void setCurrentCheckIn(CheckInRecord currentCheckIn) {
        this.currentCheckIn = currentCheckIn;
    }

    // Getter and setter for current check-out record
    public CheckOutRecord getCurrentCheckOut() {
        return currentCheckOut;
    }

    public void setCurrentCheckOut(CheckOutRecord currentCheckOut) {
        this.currentCheckOut = currentCheckOut;
    }

    // Inner class for HotelBooking
    public static class HotelBooking {
        private String guestName;
        private int roomNumber;
        private String checkInDate;
        private String checkOutDate;

        public HotelBooking(String guestName, int roomNumber, String checkInDate, String checkOutDate) {
            this.guestName = guestName;
            this.roomNumber = roomNumber;
            this.checkInDate = checkInDate;
            this.checkOutDate = checkOutDate;
        }

        // Getters and setters for HotelBooking properties
        // (Omitted for brevity)
    }

    // Inner class for CheckInRecord
    public static class CheckInRecord {
        private String guestName;
        private int roomNumber;
        private String checkInDate;

        public CheckInRecord(String guestName, int roomNumber, String checkInDate) {
            this.guestName = guestName;
            this.roomNumber = roomNumber;
            this.checkInDate = checkInDate;
        }

        // Getters and setters for CheckInRecord properties
        // (Omitted for brevity)
    }

    // Inner class for CheckOutRecord
    public static class CheckOutRecord {
        private String guestName;
        private int roomNumber;
        private String checkOutDate;

        public CheckOutRecord(String guestName, int roomNumber, String checkOutDate) {
            this.guestName = guestName;
            this.roomNumber = roomNumber;
            this.checkOutDate = checkOutDate;
        }

        // Getters and setters for CheckOutRecord properties
        // (Omitted for brevity)
    }
}

    
    
    
    
    
    
    
    
    
