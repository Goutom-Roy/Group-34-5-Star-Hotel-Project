/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package SecurityManager;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class SecurityManagerController implements Initializable {

    @FXML
    private Button SecurityAlertfxid;
    @FXML
    private Button Supportfxid;
    @FXML
    private Button Dutiefxid;
    @FXML
    private Button SecurityReportfxid;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void OnClickSecurityAlertAction(ActionEvent event) {
    }

    @FXML
    private void OnClickSupportAction(ActionEvent event) {
    }

    @FXML
    private void OnClickDutieAction(ActionEvent event) {
    }

    @FXML
    private void OnClickSecurityReportAction(ActionEvent event) {
    }
    
}
