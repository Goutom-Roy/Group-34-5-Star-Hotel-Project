/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package fivestarhotel;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class GuestComplaintController implements Initializable {

    @FXML
    private Button Roomcleanlinessfxid;
    @FXML
    private Button SlowServicefxid;
    @FXML
    private Button TemperatureControlfxid;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void OnClickRoomcleanlinessAction(ActionEvent event) {
    }

    @FXML
    private void OnClickSlowServiceAction(ActionEvent event) {
    }

    @FXML
    private void OnClickTemperatureControlAction(ActionEvent event) {
    }
    
}
